The teaching corpus — Artificial Intelligence, from the Inside
Sapienza PhD Soft Skills 2026 · https://fabsilvestri.github.io/ai-from-the-inside/

This zip IS what the course exercises use. Every prompt that reads the corpus
begins by downloading it from the address above and unzipping it, so that a
prompt works wherever you paste it. Unzip it in your working directory and the
files land exactly where the prompts expect them.

Each notebook also carries the same files internally and unpacks them in its
first cell, so a class still runs if the site is unreachable. Both routes
produce an identical layout; it never matters which one ran.

WHAT IS IN HERE
  letters.csv        800 letters. Columns:
                       id         L0001 … L0800
                       text       the letter
                       label      petition | report — the label you train on,
                                  and about one in eight of them is WRONG on purpose
                       true_label the clean label. Used only to show you what the
                                  noise did. Never train or evaluate on it.
                       iso_date   the date in one consistent format
                       topic      what the letter is about
  archive/           240 of the same letters (L0001–L0240) as individual .txt
                     files, for the document-search exercises.
  pdfs/              6 of the letters (L0241–L0246) as PDFs, so that "extract the
                     text first" is a real step and not a formality.
  dates_gold.csv     20 letters with a hand-checked correct_date, used to score
                     the prompt tournament in Notebook 5.

  images/            400 galaxy images, 48x48 greyscale PNG, in two classes:
                     spiral and elliptical. Used in Notebook 2.
  images_labels.csv    filename, label, survey.
                     THE SURVEY COLUMN IS A TRAP, and deliberately so. In this
                     folder 98% of the spirals carry a small bright square in
                     the top-left corner — a "survey stamp" from the Mirasole
                     survey. It has nothing to do with morphology, and a
                     classifier trained here will happily key on it instead of
                     on the galaxy.
  images_clean/      120 more of the same two classes, with the stamp spread
                     evenly across both. The shortcut is worthless here, so
                     this is where the first model's accuracy falls over.
  images_clean_labels.csv   same three columns.

AN HONEST WARNING
  Neither collection is real. The galaxies were drawn by a short numpy script
  (data/make_images.py in the course repository); they are not observations of
  anything, and no astronomical conclusion can be drawn from them.

  This archive is CONSTRUCTED, not historical. It was generated for teaching. The
  letters imitate a 17th-century Italian correspondence, but no line of it is a
  real historical source. Do not cite it, and do not use it as evidence about
  anything. Its defects — noisy labels, five inconsistent date formats, some
  letters in Italian — are deliberate, because a corpus that behaves perfectly
  teaches nothing about what goes wrong.

REUSE
  Released with the course materials for teaching and research use.
