The teaching corpus — Artificial Intelligence, from the Inside
Sapienza PhD Soft Skills 2026 · https://fabsilvestri.github.io/ai-from-the-inside/

You do NOT need these files to do the course. Every notebook carries the corpus
inside it and unpacks it in the first cell. This zip is here only for using the
material outside Colab, or in your own teaching.

WHAT IS IN HERE
  letters.csv        800 letters. Columns:
                       id         L0001 … L0800
                       text       the letter
                       label      petition | report — the label you train on,
                                  and about one in eight of them is WRONG on purpose
                       true_label the clean label. Used only to show you what the
                                  noise did. Never train or evaluate on it.
                       iso_date   the date in one consistent format
                       topic      what the letter is about
  archive/           240 of the same letters (L0001–L0240) as individual .txt
                     files, for the document-search exercises.
  pdfs/              6 of the letters (L0241–L0246) as PDFs, so that "extract the
                     text first" is a real step and not a formality.
  dates_gold.csv     20 letters with a hand-checked correct_date, used to score
                     the prompt tournament in Notebook 5.

AN HONEST WARNING
  This archive is CONSTRUCTED, not historical. It was generated for teaching. The
  letters imitate a 17th-century Italian correspondence, but no line of it is a
  real historical source. Do not cite it, and do not use it as evidence about
  anything. Its defects — noisy labels, five inconsistent date formats, some
  letters in Italian — are deliberate, because a corpus that behaves perfectly
  teaches nothing about what goes wrong.

REUSE
  Released with the course materials for teaching and research use.
